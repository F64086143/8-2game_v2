import pygame
import os

# screen size
WIN_WIDTH = 1024
WIN_HEIGHT = 600
# frame rate
FPS = 60
# color
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
PURPLE = (147, 0, 147)
# enemy path
PATH = [(1010, 475), (994, 500), (971, 525), (952, 541), (932, 553), (902, 550), (879, 532),
        (860, 511), (833, 488), (805, 483), (777, 467), (767, 437), (743, 416), (715, 407),
        (702, 421), (697, 461), (683, 487), (662, 504), (636, 519), (608, 531), (588, 506),
        (566, 484), (532, 457), (518, 471), (495, 504), (464, 520), (439, 484), (425, 456),
        (384, 456), (368, 468), (347, 480), (324, 498), (284, 516), (255, 491), (235, 459), (211, 468)]
PATH2 = [(11, 565), (23, 548), (44, 562), (78, 568), (109, 576), (162, 575), (205, 560), (232, 532),
        (242, 516), (264, 491), (301, 486), (333, 486), (363, 507), (383, 536), (408, 554), (427, 561),
        (466, 567), (503, 569), (547, 564), (570, 545), (582, 531), (611, 538), (636, 554), (668, 568),
        (713, 571), (750, 543), (758, 517), (806, 505), (844, 510), (883, 534), (923, 545)]


# base
BASE = pygame.Rect(120, 250, 230, 300)
BASE2 = pygame.Rect(620, 250, 230, 300)
BASE3 = pygame.Rect(300, 200, 230, 300)

# image
BACKGROUND_IMAGE = pygame.image.load(os.path.join("images", "back.png"))
HP_GRAY_IMAGE = pygame.transform.scale(pygame.image.load("images/heart2.png"), (28, 28))
HP_IMAGE = pygame.transform.scale(pygame.image.load("images/heart.png"), (28, 28))
BOY_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "boy.png")), (300, 300))
TRYAGAIN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "tryagain.png")), (200, 70))
MENU_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "list.png")), (420, 250))
MAP_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "bigmap.png")), (1024, 600))
#前導
BEFORE_IMAGE=pygame.transform.scale(pygame.image.load(os.path.join("images", "before.gif")), (1024, 600))

# 二三關圖片
BACKGROUND2_IMAGE = pygame.image.load(os.path.join("images", "road.png"))
BACKGROUND3_IMAGE = pygame.image.load(os.path.join("images", "airport.jpg"))
