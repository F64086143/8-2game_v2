import pygame
from game2.controller2 import GameControl2
from game2.model2 import GameModel2
from game2.view2 import GameView2
from settings import FPS


class Game2:
    def run2(self):
        #initialization
        pygame.init()
        game_model = GameModel2()  # core of the game (database, game logic...)
        game_view = GameView2()  # render everything
        game_control = GameControl2(game_model, game_view)  # deal with the game flow and user request
        quit_game = False
        while not quit_game:
            pygame.time.Clock().tick(FPS)  # control the frame rate
            game_control.receive_user_input()  # receive user input
            game_control.update_model()  # update the model
            game_control.update_view()  # update the view
            pygame.display.update()
            quit_game = game_control.quit_game
